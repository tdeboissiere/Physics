from ROOT import *
import PyROOTPlots as PyRPl

h1 = TH1F()
h2 = TH1F()
h3 = TH1F()
h4 = TH1F()
h5 = TH1F()
h6 = TH1F()
h7 = TH1F()
h8 = TH1F()

h2D1 = TH2F()
h2D2 = TH2F()
h2D3 = TH2F()
h2D4 = TH2F()
h2D5 = TH2F()
h2D6 = TH2F()
h2D7 = TH2F()
h2D8 = TH2F()

tFID824, fFID824 = PyRPl.open_ROOT_object("../ROOT_files/Axion/FID824_skimmed_axion.root", "t_axion")
# fFID824 = TFile("../ROOT_files/Axion/FID824_skimmed_axion.root", "read")
# tFID824 = fFID824.Get("t_axion")
tFID824.Draw("JOUR>>hist1(100, 0, 300)",  "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")
tFID824.Draw("EFID:EC>>hist2D1(100, 0, 15, 100, 0, 15)",  "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")

hist1.Copy(h1)
hist2D1.Copy(h2D1)

tFID825, fFID825 = PyRPl.open_ROOT_object("../ROOT_files/Axion/FID825_skimmed_axion.root", "t_axion")
tFID825.Draw("JOUR>>hist2(100, 0, 300)", "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")
tFID824.Draw("EFID:EC>>hist2D2(100, 0, 15, 100, 0, 15)",  "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")

hist2.Copy(h2)
hist2D2.Copy(h2D2)

tFID827, fFID827 = PyRPl.open_ROOT_object("../ROOT_files/Axion/FID827_skimmed_axion.root", "t_axion")
tFID827.Draw("JOUR>>hist3(100, 0, 300)", "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")
tFID827.Draw("EFID:EC>>hist2D3(100, 0, 15, 100, 0, 15)",  "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")

hist3.Copy(h3)
hist2D3.Copy(h2D3)

tFID837, fFID837 = PyRPl.open_ROOT_object("../ROOT_files/Axion/FID837_skimmed_axion.root", "t_axion")
tFID837.Draw("JOUR>>hist4(100, 0, 300)", "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")
tFID837.Draw("EFID:EC>>hist2D4(100, 0, 15, 100, 0, 15)",  "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")

hist4.Copy(h4)
hist2D4.Copy(h2D4)

tFID838, fFID838 = PyRPl.open_ROOT_object("../ROOT_files/Axion/FID838_skimmed_axion.root", "t_axion")
tFID838.Draw("JOUR>>hist5(100, 0, 300)", "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")
tFID838.Draw("EFID:EC>>hist2D5(100, 0, 15, 100, 0, 15)",  "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")

hist5.Copy(h5)
hist2D5.Copy(h2D5)

tFID839, fFID839 = PyRPl.open_ROOT_object("../ROOT_files/Axion/FID839_skimmed_axion.root", "t_axion")
tFID839.Draw("JOUR>>hist6(100, 0, 300)", "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")
tFID839.Draw("EFID:EC>>hist2D6(100, 0, 15, 100, 0, 15)",  "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")

hist6.Copy(h6)
hist2D6.Copy(h2D6)

tFID841, fFID841 = PyRPl.open_ROOT_object("../ROOT_files/Axion/FID841_skimmed_axion.root", "t_axion")
tFID841.Draw("JOUR>>hist7(100, 0, 300)", "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")
tFID841.Draw("EFID:EC>>hist2D7(100, 0, 15, 100, 0, 15)",  "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")

hist7.Copy(h7)
hist2D7.Copy(h2D7)

tFID842, fFID842 = PyRPl.open_ROOT_object("../ROOT_files/Axion/FID842_skimmed_axion.root", "t_axion")
tFID842.Draw("JOUR>>hist8(100, 0, 300)", "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")
tFID842.Draw("EFID:EC>>hist2D8(100, 0, 15, 100, 0, 15)",  "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")

hist8.Copy(h8)
hist2D8.Copy(h2D8)

h1.Add(h2)
h1.Add(h3)
h1.Add(h4)
h1.Add(h5)
h1.Add(h6)
h1.Add(h7)
h1.Add(h8)

h1.Draw()
print h1.Integral()

cc =TCanvas("cc", "cc")

h2D1.Add(h2D2)
h2D1.Add(h2D3)
h2D1.Add(h2D4)
h2D1.Add(h2D5)
h2D1.Add(h2D6)
h2D1.Add(h2D7)
h2D1.Add(h2D8)

h2Dbis1 = TH2F()
h2Dbis2 = TH2F()
h2Dbis3 = TH2F()
h2Dbis4 = TH2F()
h2Dbis5 = TH2F()
h2Dbis6 = TH2F()
h2Dbis7 = TH2F()
h2Dbis8 = TH2F()

tFID824.Draw("EFID:EC>>hist2Dbis1(100, 0, 15, 100, 0, 15)",  "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")
hist2Dbis1.Copy(h2Dbis1)

tFID824.Draw("EFID:EC>>hist2Dbis2(100, 0, 15, 100, 0, 15)",  "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")
hist2Dbis2.Copy(h2Dbis2)

tFID827.Draw("EFID:EC>>hist2Dbis3(100, 0, 15, 100, 0, 15)",  "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")
hist2Dbis3.Copy(h2Dbis3)

tFID837.Draw("EFID:EC>>hist2Dbis4(100, 0, 15, 100, 0, 15)",  "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")
hist2Dbis4.Copy(h2Dbis4)

tFID838.Draw("EFID:EC>>hist2Dbis5(100, 0, 15, 100, 0, 15)",  "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")
hist2Dbis5.Copy(h2Dbis5)

tFID839.Draw("EFID:EC>>hist2Dbis6(100, 0, 15, 100, 0, 15)",  "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")
hist2Dbis6.Copy(h2Dbis6)

tFID841.Draw("EFID:EC>>hist2Dbis7(100, 0, 15, 100, 0, 15)",  "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")
hist2Dbis7.Copy(h2Dbis7)

tFID842.Draw("EFID:EC>>hist2Dbis8(100, 0, 15, 100, 0, 15)",  "EIA<2*FWIA/2.3548 && EIC<2*FWIC &&(EC-EFID)<1.3 && EC>0.9 && EFID>1 && Ebest>10 && Ebest<11")
hist2Dbis8.Copy(h2Dbis8)


h2Dbis1.Add(h2Dbis2)
h2Dbis1.Add(h2Dbis3)
h2Dbis1.Add(h2Dbis4)
h2Dbis1.Add(h2Dbis5)
h2Dbis1.Add(h2Dbis6)
h2Dbis1.Add(h2Dbis7)
h2Dbis1.Add(h2Dbis8)
h2Dbis1.SetMarkerColor(kRed)
h2D1.Draw()
h2Dbis1.Draw("same")


raw_input()